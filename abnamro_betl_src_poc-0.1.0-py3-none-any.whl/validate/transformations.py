from pyspark.sql import SparkSession

from src.utils.logging_util import get_logger
from src.validate.base import BaseValidate
from src.validate.validate_sql import validate_sql_expressions

logger = get_logger()


JOIN_ON_OPTIONS = [
    "inner",
    "cross",
    "outer",
    "full",
    "fullouter",
    "full_outer",
    "left",
    "leftouter",
    "left_outer",
    "right",
    "rightouter",
    "right_outer",
    "semi",
    "leftsemi",
    "left_semi",
    "anti",
    "leftanti",
    "left_anti",
]


class Transformations(BaseValidate):
    def __init__(
        self,
        spark: SparkSession,
        business_logic: dict,
    ) -> None:
        super().__init__(spark, business_logic)
        self.transformations = self.business_logic["transformations"]
        self.sources = self.business_logic["sources"]
        self.alias = [src["alias"] for src in self.sources if "alias" in src.keys()]

    def validate(self) -> bool:
        validations = all(
            [self.validate_transformation_step(tf) for tf in self.transformations]
        )
        if validations:
            logger.info("Transformations validated successfully")
        return validations

    def validate_transformation_step(self, tf: dict) -> bool:
        if "join" in tf:
            return self.validate_joins(tf["join"])
        elif "aggregation" in tf:
            return self.validate_aggregations(tf["aggregation"])
        logger.warning("No join or aggregation in transformation steps")
        return True

    def validate_join_source(self, join: dict, left_or_right: str) -> bool:
        if (join[f"{left_or_right}_source"]) not in self.alias:
            logger.error(f"Problem with join {join}")
            logger.error(
                f"No {left_or_right.title()} {join[f'{left_or_right}_source']}.",
            )
            logger.error(f"Available alias: {self.alias}")
            return False
        return True

    def validate_joins(self, join: dict) -> bool:
        if not self.validate_join_source(join, "left"):
            return False
        if not self.validate_join_source(join, "right"):
            return False
        validate_join_conditions(self.spark, self.sources, join["condition"])
        if join.get("how", "left") not in JOIN_ON_OPTIONS:
            logger.error(f"Problem with join {join}")
            logger.error(f"how option '{join['how']}' is not a valid option")
            logger.error(f"Possible values for 'how': {JOIN_ON_OPTIONS}")
            return False
        logger.info("Joins validated successfully")
        return True

    def validate_aggregations(self, agg: dict) -> bool:
        available_columns = set(
            [
                f"{source['alias']}.{col}"
                for source in self.sources
                for col in source["columns"]
            ]
        )
        group_cols = set(agg["group"])
        agg_cols = set(agg["agg"].keys())
        if not (group_cols.union(agg_cols)).issubset(available_columns):
            not_in_list = (group_cols.union(agg_cols)) - available_columns
            logger.error(f"Problem with group/aggregation columns {not_in_list}")
            logger.error(f"Available columns: {available_columns}")
            return False
        logger.info("Aggregations validated successfully")
        return True


def validate_join_conditions(
    spark: SparkSession, sources: list, conditions: list
) -> bool:
    """Validate join conditions from business logic mapping.

    Args:
        spark (SparkSession): SparkSession
        sources (list): Business logic mapping
        conditions (list): List of conditions to validate

    Returns:
        bool: True, if join conditions are succesfully validated.
    """
    cond_parts = {
        f"join_{cond_idx}_{part}": conditions[cond_idx].split("=")[part]
        for cond_idx in range(len(conditions))
        for part in range(2)
    }
    if validate_sql_expressions(spark, sources, cond_parts):
        logger.debug("Join condition expressions validated successfully")
        return True
    return False
