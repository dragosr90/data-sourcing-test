from pyspark.sql import SparkSession
from pyspark.sql.utils import AnalysisException, ParseException

from src.utils.logging_util import get_logger
from src.validate.base import BaseValidate

logger = get_logger()


class Sources(BaseValidate):
    def __init__(self, spark: SparkSession, business_logic: dict) -> None:
        super().__init__(spark, business_logic)
        self.sources = self.business_logic["sources"]

    def validate(self) -> bool:
        """Validate sources from list of sources.

        Args:
            spark (SparkSession): SparkSession
            sources (list): List of sources to validate

        Returns:
            bool: True, if sources are succesfully validated.
        """
        for source in self.sources:
            try:
                (
                    self.spark.read.table(source["source"])
                    .alias(source["alias"])
                    .select(source["columns"])
                    .transform(
                        lambda x: x.filter(source["filter"])  # noqa: B023
                        if "filter" in source.keys()  # noqa: B023
                        else x
                    )
                )
            except ParseException as e:
                logger.error(f"Incorrect syntax for source {source}")
                logger.error(str(e).split(";")[0])
                return False
            except AnalysisException as e:
                logger.error(f"Problem with table/columns for source {source}")
                logger.error(str(e).split(";")[0])
                return False
        logger.info("Sources validated successfully")
        return True
