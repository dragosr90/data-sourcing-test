import pyspark.sql.functions as sf
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

from src.utils.logging_util import get_logger
from src.validate.base import BaseValidate
from src.validate.validate_sql import validate_sql_expressions

logger = get_logger()


class Variables(BaseValidate):
    def __init__(
        self,
        spark: SparkSession,
        business_logic: dict,
    ) -> None:
        super().__init__(spark=spark, business_logic=business_logic)
        self.transformations = self.business_logic.get("transformations")
        self.sources = self.business_logic["sources"]
        self.variables = self.business_logic["variables"]

    def validate(self) -> bool:
        """Validate variables from business logic mapping."""
        agg_cols = (
            [
                getattr(sf, fun)(col(c)).alias(f"{fun}_{c.replace('.','_')}")
                for c, fun in self.transformations[-1]["aggregation"]["agg"].items()
            ]
            if (
                self.transformations
                and "aggregation" in self.transformations["transformations"]
            )
            else []
        )
        if not validate_sql_expressions(
            self.spark, self.sources, self.variables, agg_cols
        ):
            return False
        logger.info("Variables validated successfully")
        return True
