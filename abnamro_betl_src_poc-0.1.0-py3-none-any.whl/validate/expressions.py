from pyspark.sql import SparkSession

from src.utils.logging_util import get_logger
from src.validate.base import BaseValidate
from src.validate.validate_sql import validate_sql_expressions

logger = get_logger()


class Expressions(BaseValidate):
    def __init__(
        self,
        spark: SparkSession,
        business_logic: dict,
    ) -> None:
        super().__init__(spark, business_logic)
        self.sources = self.business_logic["sources"]
        self.expressions = self.business_logic["expressions"]
        self.transformations = self.business_logic.get("transformations")
        self.variables = self.business_logic.get("variables")

    def validate(self) -> bool:
        """Validate expressions from business logic mapping."""
        # Make aggregation fields and variables available if they get created
        # TODO: when there is an aggregation, ignore the source fields?
        agg_cols = (
            [
                f"{fun}_{c.replace('.','_')}"
                for c, fun in self.transformations[-1]["aggregation"]["agg"].items()
            ]
            if (self.transformations and "aggregation" in self.transformations[-1])
            else []
        )
        var_cols = list(self.variables.keys()) if self.variables else []
        if not validate_sql_expressions(
            self.spark,
            self.sources,
            self.expressions,
            agg_cols + var_cols,
        ):
            return False
        logger.info("Target expressions validated successfully")
        return True
