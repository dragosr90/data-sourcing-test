from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
from pyspark.sql.utils import AnalysisException, ParseException

from src.utils.alias_util import get_aliases_on_dataframe
from src.utils.logging_util import get_logger

logger = get_logger()


def validate_sql_expressions(
    spark: SparkSession,
    sources: list[dict],
    expressions: dict[str, str],
    extra_cols: list[str] | None = None,
) -> bool:
    """Validate the SQL expressions from an input list of sources and expressions.

    First, create dummy dataframe with all columns available for the expressions.

    Args:
        spark (SparkSession): SparkSession
        sources (list): sources as list from `business_logic["sources"]`
        expressions (dict): mapping of target columns and input columns
        extra_cols (list, optional): Optional addititional columns. Defaults to None.

    Returns:
        bool: True if SQL expressions are successfully
    """
    if extra_cols is None:
        extra_cols = []
    tablecolumn_list = [
        f"{source['alias']}.{col}" for source in sources for col in source["columns"]
    ]
    empty_data = spark.createDataFrame(
        [], ", ".join([f"`{col}`: string" for col in tablecolumn_list])
    )
    data = get_aliases_on_dataframe(data=empty_data, input_field_names=tablecolumn_list)
    data = (
        data.withColumns({extra_col: lit("") for extra_col in extra_cols})
        if extra_cols
        else data
    )
    expr_list = []
    for column, logic in expressions.items():
        if len(column) == 0:
            logger.error(f"Missing column name for\n  {column}: {logic}")
            return False
        if len(logic) == 0:
            logger.error(f"No value/expression given for column {column}")
            return False
        expr_list.append(logic + " as " + column)
    for expr in expr_list:
        try:
            data = data.selectExpr("*", expr)
        except ParseException as e:
            logger.error(f"Incorrect syntax for: {expr}")
            logger.error(str(e).split(";")[0])
            return False
        except AnalysisException as e:
            logger.error(f"Problem with table/columns for: {expr}")
            logger.error(str(e).split(";")[0])
            return False
    return True
