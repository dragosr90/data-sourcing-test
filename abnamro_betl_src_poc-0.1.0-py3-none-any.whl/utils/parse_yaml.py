import yaml

from src.config.constants import PROJECT_ROOT_DIRECTORY


def parse_yaml(yaml_path: str) -> dict:
    with open(PROJECT_ROOT_DIRECTORY / "business_logic" / yaml_path) as yaml_file:
        cleaned_yaml = (
            yaml_file.read()
            .replace('"', "'''")
            .replace("NULL", "'NULL'")
            .replace("null", "'null'")
        )
        business_logic = yaml.safe_load(cleaned_yaml)

    for key in business_logic["expressions"]:
        business_logic["expressions"][key] = str(business_logic["expressions"][key])
    return business_logic
