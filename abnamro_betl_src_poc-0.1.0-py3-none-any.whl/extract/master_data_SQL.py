import pyspark.sql.functions as sf
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col, expr

from src.utils.logging_util import get_logger

logger = get_logger()


class GetIntegratedData:
    """Get Integrated data, using configuration of `business_logic` input file"""

    def __init__(
        self,
        spark: SparkSession,
        business_logic: dict,
        catalog: str = "baselsrc_d",
        database: str = "poc_basel_sourcing",
        local: bool = False,
    ) -> None:
        """
        Args:
            spark (SparkSession): Spark session
            business_logic (dict): Configuration for data processing
            catalog (str): Databricks catalog name
            database (str): Databricks database (schema) name
            local (bool): True if method is locally executed
        """
        self.spark = spark
        self.sources = business_logic["sources"]
        self.transformations = business_logic.get("transformations", [{}])
        self.variables = business_logic.get("variables", {})
        self.catalog = catalog
        self.database = database
        if not local:
            self.spark.sql(f"""USE CATALOG {catalog};""")
            self.spark.sql(f"""USE DATABASE {database};""")

    def get_integrated_data(self) -> DataFrame:
        """Get integrated dataset by reading, filtering, joining and aggregating."""
        data_dict = self.read_source_data()
        integrated_data = self.join_data(data_dict=data_dict)
        last_transform_step = self.transformations[-1]
        if "aggregation" in last_transform_step:
            integrated_data = self.aggregate_data(
                integrated_data, **last_transform_step["aggregation"]
            )
        if len(self.variables) > 0:
            integrated_data = self.add_variables(integrated_data)
        return integrated_data

    def read_source_data(self) -> dict[str, DataFrame]:
        """Read and (optionally) filter all source data from catalog."""
        return {
            source["alias"]: (
                self.spark.read.table(source["source"])
                .alias(source["alias"])
                .select(source["columns"])
                .transform(
                    lambda x: x.filter(source["filter"])  # noqa: B023
                    if "filter" in source.keys()  # noqa: B023
                    else x
                )
            )
            for source in self.sources
        }

    def join_data(self, data_dict: dict[str, DataFrame]) -> DataFrame:
        """Join all data from `data_dict` according to config in business_logic."""
        # If there are no transformations, return first table
        if self.transformations == [{}]:
            return next(iter(data_dict.values()))
        # Take initial left table as 'master' d
        joined_data = data_dict[self.transformations[0]["join"]["left_source"]]
        for tf in self.transformations:
            if "join" in tf and "condition" in tf["join"]:
                join = tf["join"]
                join_cond = [
                    expr(c.split("=")[0].replace(" ", ""))
                    == expr(c.split("=")[1].replace(" ", ""))
                    for c in join["condition"]
                ]
                joined_data = joined_data.join(
                    data_dict[join["right_source"]],
                    on=join_cond,
                    how=join.get("how", "left"),
                )
        return joined_data

    @staticmethod
    def aggregate_data(data: DataFrame, group: list, agg: dict) -> DataFrame:
        """Aggregate Integrated Dataset.

        Since columns are aggregated, table aliases will be lost.
        Therefore the output columns will be renamed based on the
        table alias and the aggregation function. So `max('TBLA.col1')`
        will be renamed to `'max_TBLA_col1'`.

        Args:
            data (DataFrame): Input (Integrated) DataFrame
            group (list[str]): List of column names to group data
            agg (dict): Configuration for aggregation, with the keys as
                input columns and the values as aggregation function
                from `pyspark.sql.functions`

        Returns:
            DataFrame: Aggregated integrated dataset
        """
        return data.groupby(group).agg(
            *[
                getattr(sf, fun)(col(c)).alias(f"{fun}_{c.replace('.','_')}")
                for c, fun in agg.items()
            ]
        )

    def add_variables(self, data: DataFrame) -> DataFrame:
        """Add all variables as extra columns to the integrated dataset"""
        for var in self.variables.keys():
            var_expression = self.variables[var]
            data = data.selectExpr(["*", f"{var_expression} AS {var}"])
        return data
