from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col


def get_full_master_data(
    spark: SparkSession,
    catalog: str = "baselsrc_d",
    database: str = "poc_basel_sourcing",
    local: bool = False,
) -> DataFrame:  # pragma: no cover
    """Get full master data, joining all datasets on `global_id_col` to EPR party data.

    Args:
        spark (SparkSession): Spark session
        catalog (str): Databricks catalog name
        datase (str): Databricks database (schema) name
        local (bool): True if method is locally executed

    Returns:
        DataFrame: Combined dataset (on Global ID) with attributes from EPR Party,
            Organisation, Address, Classification, External ID, Local ID,
            Relationships, and Financial details.
    """
    # Set Catalog and Database, disable for unit testing
    if not local:
        spark.sql(f"""USE CATALOG {catalog};""")
        spark.sql(f"""USE DATABASE {database};""")

    EPR_ENT_PARTY = (
        spark.read.table("enterprise_party_delt")
        .alias("EPR_ENT_PARTY")
        .select("o_GLOBAL_ID", "o_SNAPSHOTDATE", "o_PRTY_TYP", "o_PRTY_NM")
    )
    EPR_ENT_PARTY_UP, EPR_ENT_PARTY_HO, EPR_ENT_PARTY_DP = (
        spark.read.table("enterprise_party_delt").alias(alias).select("o_GLOBAL_ID")
        for alias in ["EPR_ENT_PARTY_UP", "EPR_ENT_PARTY_HO", "EPR_ENT_PARTY_DP"]
    )

    EPR_RLTN_DP, EPR_RLTN_UP, EPR_RLTN_HO = (
        spark.read.table("epr_party_relationship_delt")
        .filter(col("o_RLTNSHP_TYP") == rlt_typ)
        .alias(alias)
        .select(
            "o_RLTNSHP_TYP",
            "o_RLTNSHP_STTS",
            "o_GLOBAL_D1",
            "o_GLOBAL_ID2",
        )
        for alias, rlt_typ in {
            "EPR_RLTN_DP": 101,
            "EPR_RLTN_UP": 102,
            "EPR_RLTN_HO": 103,
        }.items()
    )

    EPR_CLASS_SBI_01, EPR_CLASS_02_NACE, EPR_CLASS_SBI_03 = (
        spark.read.table("epr_party_classification_delt")
        .alias(alias)
        .select("o_GLOBAL_ID", "o_CLSFCTN_TYP", "o_CLSFCTN_VAL")
        .filter(col("o_CLSFCTN_TYP") == cls_typ)
        for alias, cls_typ in {
            "EPR_CLASS_SBI_01": 1,
            "EPR_CLASS_02_NACE": 2,
            "EPR_CLASS_SBI_03": 3,
        }.items()
    )
    EPR_CLASS_VAL = (
        spark.read.table("epr_party_classification_delt")
        .alias("EPR_CLASS_VAL")
        .select("o_GLOBAL_ID", "o_CLSFCTN_TYP", "o_CLSFCTN_VAL")
        .filter((col("o_CLSFCTN_STS") == 1) & (col("o_CLSFCTN_TYP") == 18))
    )

    EPR_EXT_ID_LEI = (
        spark.read.table("epr_party_external_identifier_delt")
        .alias("EPR_EXT_ID_LEI")
        .select("o_GLOBAL_ID", "o_EXTRN_ID_TYP", "o_EXTRN_ID_VAL")
        .filter(col("o_EXTRN_ID_TYP") == "LEI")
    )

    EPR_LOC_ID_INSIGHT = (
        spark.read.table("epr_party_local_identifier_delt")
        .alias("EPR_LOC_ID_INSIGHT")
        .select("o_GLOBAL_ID", "o_LOCL_SRC_SYSTM", "o_LOCL_ID")
        .filter(col("o_LOCL_SRC_SYSTM") == "INSIGHTER")
    )

    EPR_ORG = (
        spark.read.table("epr_organisation_delt")
        .alias("EPR_ORG")
        .select("o_GLOBAL_ID", "o_MAIN_COC", "o_CNTRY_OF_INCORP")
    )

    EPR_ADDRESS_PREF = (
        spark.read.table("epr_party_address_delt")
        .alias("EPR_ADDRESS_PREF")
        .select("o_GLOBAL_ID", "o_ADRES_TYPE", "o_CNTRY")
        .filter(col("o_ADRES_TYPE") == "PREF")
    )
    EPR_FINANCIAL_DET = (
        spark.read.table("organisation_financial_details_delt")
        .alias("EPR_FINANCIAL_DET")
        .select("o_global_id", "o_accnt_data_level", "o_annl_trnover", "o_accnt_crrncy")
    )
    return (
        EPR_ENT_PARTY.join(
            EPR_ORG,
            on=EPR_ENT_PARTY["o_GLOBAL_ID"] == EPR_ORG["o_GLOBAL_ID"],
            how="left",
        )
        .join(
            EPR_CLASS_02_NACE,
            on=EPR_ENT_PARTY["o_GLOBAL_ID"] == EPR_CLASS_02_NACE["o_GLOBAL_ID"],
            how="left",
        )
        .join(
            EPR_CLASS_SBI_03,
            on=EPR_ENT_PARTY["o_GLOBAL_ID"] == EPR_CLASS_SBI_03["o_GLOBAL_ID"],
            how="left",
        )
        .join(
            EPR_CLASS_SBI_01,
            on=EPR_ENT_PARTY["o_GLOBAL_ID"] == EPR_CLASS_SBI_01["o_GLOBAL_ID"],
            how="left",
        )
        .join(
            EPR_ADDRESS_PREF,
            on=EPR_ENT_PARTY["o_GLOBAL_ID"] == EPR_ADDRESS_PREF["o_GLOBAL_ID"],
            how="left",
        )
        .join(
            EPR_EXT_ID_LEI,
            on=EPR_ENT_PARTY["o_GLOBAL_ID"] == EPR_EXT_ID_LEI["o_GLOBAL_ID"],
            how="left",
        )
        .join(
            EPR_RLTN_UP,
            on=EPR_ENT_PARTY["o_GLOBAL_ID"] == EPR_RLTN_UP["o_GLOBAL_D1"],
            how="left",
        )
        .join(
            EPR_ENT_PARTY_UP,
            on=col("EPR_RLTN_UP.o_GLOBAL_ID2") == col("EPR_ENT_PARTY_UP.o_GLOBAL_ID"),
            how="left",
        )
        .join(
            EPR_RLTN_HO,
            on=EPR_ENT_PARTY["o_GLOBAL_ID"] == EPR_RLTN_HO["o_GLOBAL_D1"],
            how="left",
        )
        .join(
            EPR_ENT_PARTY_HO,
            on=col("EPR_RLTN_HO.o_GLOBAL_ID2") == col("EPR_ENT_PARTY_HO.o_GLOBAL_ID"),
            how="left",
        )
        .join(
            EPR_RLTN_DP,
            on=EPR_ENT_PARTY["o_GLOBAL_ID"] == EPR_RLTN_DP["o_GLOBAL_D1"],
            how="left",
        )
        .join(
            EPR_ENT_PARTY_DP,
            on=col("EPR_RLTN_DP.o_GLOBAL_ID2") == col("EPR_ENT_PARTY_DP.o_GLOBAL_ID"),
            how="left",
        )
        .join(
            EPR_LOC_ID_INSIGHT,
            on=EPR_ENT_PARTY["o_GLOBAL_ID"] == EPR_LOC_ID_INSIGHT["o_GLOBAL_ID"],
            how="left",
        )
        .join(
            EPR_FINANCIAL_DET,
            on=EPR_ENT_PARTY["o_GLOBAL_ID"] == EPR_FINANCIAL_DET["o_GLOBAL_ID"],
            how="left",
        )
        .join(
            EPR_CLASS_VAL,
            on=EPR_ENT_PARTY["o_GLOBAL_ID"] == EPR_CLASS_VAL["o_GLOBAL_ID"],
            how="left",
        )
    )
