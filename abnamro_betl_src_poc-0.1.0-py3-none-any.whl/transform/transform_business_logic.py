from pyspark.sql import DataFrame
from pyspark.sql.functions import col, when


def transform_business_logic_epr_party(data: DataFrame) -> DataFrame:
    """Get additional columns based on Business logic for EPR Party data."""
    return data.select(
        "*",
        col("EPR_ENT_PARTY.o_SNAPSHOTDATE").alias("SnapshotDate"),
        col("EPR_ENT_PARTY.o_GLOBAL_ID").alias("GlobalCounterpartyIdentifier"),
        col("EPR_ENT_PARTY.o_PRTY_TYP").alias("PartyType"),
        col("EPR_ENT_PARTY.o_PRTY_NM").alias("CounterpartyName"),
    )


def transform_business_logic_epr_org(data: DataFrame) -> DataFrame:
    return data.select(
        "*",
        when(col("EPR_ENT_PARTY.o_PRTY_TYP") == "ORG", col("EPR_ORG.o_MAIN_COC")).alias(
            "NationalIdentifier"
        ),
        col("EPR_ORG.o_CNTRY_OF_INCORP").alias("CountryOfIncorporation"),
    )


def transform_business_logic_epr_relation(data: DataFrame) -> DataFrame:
    return data.select(
        "*",
        col("EPR_ENT_PARTY_UP.o_GLOBAL_ID").alias("UltimateParentOrganisation"),
        when(
            col("EPR_RLTN_HO.o_RLTNSHP_TYP") == 103, col("EPR_ENT_PARTY_HO.o_GLOBAL_ID")
        ).alias("HeadOfficeOrganisation"),
        when(
            col("EPR_RLTN_DP.o_RLTNSHP_TYP") == 101, col("EPR_ENT_PARTY_DP.o_GLOBAL_ID")
        ).alias("ImmediateParentOrganisation"),
    )


def transform_business_logic_epr_class(data: DataFrame) -> DataFrame:
    return data.select(
        "*",
        when(
            col("EPR_CLASS_SBI_01.o_CLSFCTN_TYP") == 1,
            col("EPR_CLASS_SBI_01.o_CLSFCTN_VAL"),
        ).alias("OFFICIAL_SBI_CODE"),
        when(
            col("EPR_CLASS_02_NACE.o_CLSFCTN_TYP") == 2,
            col("EPR_CLASS_02_NACE.o_CLSFCTN_VAL"),
        ).alias("OFFICIAL_NACE"),
        when(
            col("EPR_CLASS_SBI_03.o_CLSFCTN_TYP") == 3,
            col("EPR_CLASS_SBI_03.o_CLSFCTN_VAL"),
        ).alias("REAL_SBI_CODE"),
        when(col("EPR_CLASS_VAL.o_CLSFCTN_VAL") == 1, "Y")
        .when(col("EPR_CLASS_VAL.o_CLSFCTN_VAL") == 2, "N")
        .alias("SME_INDICATOR"),
    )


def transform_business_logic_address(data: DataFrame) -> DataFrame:
    return data.select(
        "*",
        when(
            col("EPR_ADDRESS_PREF.o_ADRES_TYPE") == "PREF",
            col("EPR_ADDRESS_PREF.o_CNTRY"),
        ).alias("CountryOfResidence"),
    )


def transform_business_logic_epr_loc_id(data: DataFrame) -> DataFrame:
    return data.select(
        "*",
        when(
            col("EPR_LOC_ID_INSIGHT.o_LOCL_SRC_SYSTM") == "INSIGHTER",
            col("EPR_LOC_ID_INSIGHT.o_LOCL_ID"),
        ).alias("InsighterId"),
    )


def transform_business_logic_epr_ext_id(data: DataFrame) -> DataFrame:
    return data.select(
        "*",
        when(
            col("EPR_EXT_ID_LEI.o_EXTRN_ID_TYP") == "LEI",
            col("EPR_EXT_ID_LEI.o_EXTRN_ID_VAL"),
        ).alias("LeiCode"),
    )


def transform_business_logic_epr_finan(data: DataFrame) -> DataFrame:
    return data.select(
        "*",
        when(
            col("EPR_RLTN_UP.o_RLTNSHP_TYP") == 102,
            when(
                (col("EPR_FINANCIAL_DET.o_accnt_data_level") == 3)
                & (col("EPR_RLTN_UP.o_RLTNSHP_STTS") == 1),
                col("EPR_FINANCIAL_DET.o_annl_trnover"),
            ),
        ).alias("Group_Annual_Turnover"),
        when(
            col("EPR_RLTN_UP.o_RLTNSHP_TYP") == 102,
            when(
                (col("EPR_FINANCIAL_DET.o_accnt_data_level") == 3)
                & (col("EPR_RLTN_UP.o_RLTNSHP_STTS") == 1),
                col("EPR_FINANCIAL_DET.o_accnt_crrncy"),
            ),
        ).alias("Group_Annual_Turnover_Currency"),
    )


def transform_business_logic(  # pragma: no cover
    data: DataFrame, output_cols: None | list[str] = None
) -> DataFrame:
    return (
        data.transform(transform_business_logic_epr_party)
        .transform(transform_business_logic_epr_org)
        .transform(transform_business_logic_epr_relation)
        .transform(transform_business_logic_epr_class)
        .transform(transform_business_logic_address)
        .transform(transform_business_logic_epr_loc_id)
        .transform(transform_business_logic_epr_ext_id)
        .transform(transform_business_logic_epr_finan)
        .select(output_cols if output_cols else "*")
    )  # Get all required output columns
