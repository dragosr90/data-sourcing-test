from pyspark.sql import DataFrame

from src.utils.logging_util import get_logger

logger = get_logger()


def transform_business_logic_sql(
    data: DataFrame, business_logic: dict, filter_target: list[str] | None = None
) -> DataFrame:
    combined_filter = " AND ".join(filter_target) if filter_target else None
    transformed_data = data.selectExpr(
        [logic + " as " + column for column, logic in business_logic.items()]
    )
    return (
        transformed_data.filter(combined_filter)
        if combined_filter
        else transformed_data
    )
