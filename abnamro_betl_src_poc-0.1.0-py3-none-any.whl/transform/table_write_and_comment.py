from pyspark.sql import DataFrame, SparkSession


def write_to_table(table_name: str, data: DataFrame, mode: str = "overwrite") -> None:
    """Write data to table in Unity Catalog."""
    data.write.mode(mode).saveAsTable(table_name)


def transformation_dict_to_string(tf: dict) -> str:
    """Transformation business logic transformation dictionary to string values."""
    if "join" in tf:
        conditions = tf["join"]["condition"]
        how = tf["join"].get("how", "left")
        md_conditions = (
            "\n".join(conditions)
            if len(conditions) == 1
            else "\n".join([f"  - {c}" for c in conditions])
        )
        return f"- Join ({how}):\n{md_conditions}"
    elif "aggregation" in tf:
        return (
            f"- Aggregate:\n"
            f"  - group by {tf['aggregation']['group']}\n"
            f"  - functions {tf['aggregation']['agg']}"
        )
    else:
        raise ValueError(
            "Input `tf` should be a dict with one of the following keys: 'join' ,"
            f"'aggregation', input keys are: {list(tf.keys())}"
        )


def source_dict_to_string(source: dict) -> str:
    """Source business logic transformation dictionary to string values."""
    fltr_cnd = f"  \nFilter: {source['filter']}" if "filter" in source.keys() else ""
    return f"- {source['alias']} = {source['source']}{fltr_cnd}"


def table_summary(
    spark: SparkSession,
    business_logic: dict,
    sources_title: str = "#### Sources\n",
    transformations_title: str = "#### Transformations\n",
    variables_title: str = "#### Variables\n",
) -> None:
    """Create summary as comment on table."""
    sources = sources_title + "\n".join(
        [source_dict_to_string(source) for source in business_logic["sources"]]
    )
    transformations = (
        "\n\n"
        + transformations_title
        + "\n".join(
            [
                transformation_dict_to_string(tf)
                for tf in business_logic["transformations"]
            ]
        )
        if "transformations" in business_logic
        else ""
    )
    variables = (
        "\n\n"
        + variables_title
        + "".join(
            [
                f"- {var} = {business_logic['variables'][var]}"
                for var in business_logic["variables"].keys()
            ]
        )
        if "variables" in business_logic
        else ""
    )
    comment_string = f"{sources}{transformations}{variables}"
    spark.sql(f'COMMENT ON TABLE {business_logic["target"]} IS "{comment_string}"')


def target_expression_comments(spark: SparkSession, business_logic: dict) -> None:
    """Add logic as comments to columns for data lineage."""
    for tgt_col in business_logic["expressions"].keys():
        tgt_table = business_logic["target"]
        expression = business_logic["expressions"][tgt_col]
        spark.sql(
            f'ALTER TABLE {tgt_table} ALTER COLUMN {tgt_col} COMMENT "{expression}"'
        )


def write_and_comment(
    spark: SparkSession, business_logic: dict, data: DataFrame
) -> None:
    """Write data to Unity Catalog and add table & column comments from logic."""
    write_to_table(table_name=business_logic["target"], data=data)
    table_summary(spark=spark, business_logic=business_logic)
    target_expression_comments(spark=spark, business_logic=business_logic)
