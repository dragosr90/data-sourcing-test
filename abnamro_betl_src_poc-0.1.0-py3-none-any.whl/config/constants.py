from pathlib import Path

PROJECT_ROOT_DIRECTORY = Path(__file__).parent.parent.parent.resolve()
